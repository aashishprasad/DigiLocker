var app0 = angular.module('test', []);

app0.controller('ViewCtrl', function($scope, $http) {

  $http.get("https://whispering-woodland-9020.herokuapp.com/getAllBooks")
    .then(function(response) {
      $scope.data = response.data;
    });
});



var cat = angular.module("categoryList", []);
cat.controller("myCategory", function($scope) {

    var category= [{name:"Picture",id:"1"}, {name:"Document",id:"2"}, {name:"Other",id:"3"}];
    $scope.category = category;
});


var app = angular.module("pictureList", []);
app.controller("myCtrl", function($scope) {

    var picture= ["img1", "img2", "img3"];
    $scope.picture = picture;
});

angular.element(document).ready(function() { angular.bootstrap(document.getElementById("App2"), ['pictureList']); });
