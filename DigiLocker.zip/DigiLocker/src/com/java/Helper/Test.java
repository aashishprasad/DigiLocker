package com.java.Helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

import javax.crypto.SecretKey;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

public class Test {
	private static String secretkeyfilepath = "c://test//key.file";

	public static void main(String[] args) {
		try {
			EmailUtility.sendEmail("smtp.gmail.com", "587", "aashish.pd097@gmail.com", "password", "aprasad2008@gmail.com","Test","This is a test mail.");
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main2(String[] args) {
		File keyfile = new File(secretkeyfilepath);
		if (!keyfile.exists()) {
			// generating secret key and saving in a file.
			try {
				SecretKey originalKey = KeyStoreUtils.generateKey();

				File file = new File(secretkeyfilepath);
				KeyStoreUtils.saveKey(originalKey, file);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main1(String[] args) {
		File file = new File("c://test//key.file");
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));

			String line = null;

			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
