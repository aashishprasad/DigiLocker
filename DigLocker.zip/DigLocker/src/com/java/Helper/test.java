package com.java.Helper;

import org.apache.log4j.Logger;


public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final Logger logger = Logger.getLogger(test.class);
		logger.error("test");

	}

}
