package com.java.rest.webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataParam;

import Controller.UserAuthentication;
import Controller.Validation;

import com.java.DAO.MyUserDAO;
import com.java.model.User;

@Path("/user")
public class UserService {

	@POST
	@Path("/login")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response login(@FormDataParam("username") String username,
			@FormDataParam("password") String password) {

		if (username.equals("") || password.equals("")) {
			return Response.status(200).entity(
					"Username or Password cannot be blank.").build();
		} else {

			User user = new User();
			user.setUsername(username);
			user.setPassword(password);

			UserAuthentication auth = new UserAuthentication(user);
			boolean result = auth.UserValidate();

			if (result) {
				// create new session and store it in database.
				return Response.status(200).entity("Login Successful").build();
			} else {
				return Response.status(200).entity("Login Failed").build();
			}
		}

	}

	@POST
	@Path("/register")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response register(@FormDataParam("username") String username,
			@FormDataParam("password") String password,
			@FormDataParam("name") String name,
			@FormDataParam("email") String email,
			@FormDataParam("mobile") String mobile) {

		if (username.equals("") || password.equals("") || name.equals("")
				|| email.equals("") || mobile.equals("")) {
			return Response.status(200).entity("All fields are mandatory.")
					.build();
		} else {

			User user = new User();
			user.setUsername(username);
			user.setPassword(password);
			user.setName(name);
			user.setEmail(email);
			user.setMobile(mobile);

			MyUserDAO d = new MyUserDAO();

			Validation valid = new Validation();
			boolean usernameisvalid = valid.validateUsername(username);// validating
																		// username

			if (usernameisvalid) {

				boolean emailisvalid = valid.validateEmail(email);
				if (emailisvalid) {
					boolean result = d.createNewUser(user);
					if (result) {
						return Response.status(200).entity(
								"Registration Successful.").build();
					} else {
						return Response.status(200).entity(
								"Registration Failed. Please try again later.")
								.build();
					}
				} else {
					return Response
							.status(200)
							.entity(
									"Email ID is already registered with an account. Please enter a valid email ID.")
							.build();
				}
			} else {
				return Response.status(200).entity(
						"User Already Exists. Please enter a valid username.")
						.build();
			}

		}
	}

}
