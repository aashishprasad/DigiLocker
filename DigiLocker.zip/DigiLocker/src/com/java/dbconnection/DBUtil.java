package com.java.dbconnection;

import java.sql.*;

public class DBUtil {

	private Connection connection = null;

	public Connection getConnection() {
		if (connection != null)
			return connection;
		else {
			try {
				// step1 load the driver class
				Class.forName("oracle.jdbc.driver.OracleDriver");

				// step2 create the connection object
				connection = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:xe", "aashish",
						"aashu");

				return connection;
			} catch (Exception e) {
				System.out.println(e);
			}

		}
		return connection;
	}
}
