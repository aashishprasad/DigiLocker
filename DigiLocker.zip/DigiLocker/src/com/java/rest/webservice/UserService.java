package com.java.rest.webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataParam;

@Path("/user")
public class UserService {
	
	@POST
	@Path("/login")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response login(	@FormDataParam("username") String name,
			@FormDataParam("password") String pass){
		
		System.out.println("Username:"+name);
		System.out.println("Password:"+pass);
		return Response.status(200).entity("User Service").build();
		
	}

}
