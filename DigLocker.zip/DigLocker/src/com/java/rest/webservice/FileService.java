package com.java.rest.webservice;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;


import org.apache.log4j.Logger;

import com.java.DAO.MyFileDAO;
import com.java.Helper.Encryption;
import com.java.Helper.GetFileExtension;
import com.java.exception.MyExceptionHandler;
import com.java.model.FileModel;
import com.java.model.ResponseMessage;
import com.java.resource.property.PropertyLoader;
import com.oreilly.servlet.MultipartRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

public class FileService {

	private boolean result;
	private String output;
	final static Logger logger = Logger.getLogger(FileService.class);

	public ResponseMessage uploadFile(HttpServletRequest request)
			throws MyExceptionHandler {
		String fileLocation = "";
		String fileName = "";
		try {
			// saving file on server.
			MultipartRequest m = new MultipartRequest(request, PropertyLoader
					.getPropertyValue("dcryptedfilepath"));

			/*
			 * Enumeration params = m.getParameterNames(); while
			 * (params.hasMoreElements()) { String name = (String)
			 * params.nextElement(); String value = m.getParameter(name);
			 * System.out.println("name : " + name);
			 * System.out.println("value : " + value);
			 * System.out.println("--------");
			 * 
			 * }
			 */

			// get File Name Receive
			Enumeration files = m.getFileNames();
			while (files.hasMoreElements()) {
				String name = (String) files.nextElement();
				fileName = m.getFilesystemName(name);
				// String type = m.getContentType(name);
				// File f = m.getFile(name);

				// System.out.println("Test fileName : ");
				// System.out.println("name : " + name);
				// System.out.println("fileName : " + fileName);
				// System.out.println("type : " + type);
				// System.out.println("----");
				/*
				 * if (f != null) { System.out.println("length : " +
				 * f.length()); }
				 */
			}

			fileLocation = PropertyLoader.getPropertyValue("dcryptedfilepath")
					+ fileName;

			// getting parameter values into FileModel object.
			FileModel f1 = new FileModel();
			f1.setFileName(m.getParameter("filename"));
			// f1.setUserID(userID);
			f1.setDescription(m.getParameter("file_description"));
			// f1.setCategory_ID(category_id);
			f1.setFileType(GetFileExtension.getFileExtension(fileLocation));// getting
			// file_extension.

			FileService service = new FileService();// object of FileService
			// class.
			if (m.getParameter("secure") != null) {
				f1.setSecure("yes");
				String oldFileLocation = fileLocation;
				// encrypting file.
				Encryption enc = new Encryption();
				fileLocation = enc.encryptFile(fileLocation, f1.getFileName());

				// deleting old file from server.
				service.delete(oldFileLocation);

			} else {
				f1.setSecure("no");

				// file uploading in database.
				MyFileDAO d = new MyFileDAO();
				result = d.uploadFile(fileLocation, f1);

				// deleting file from server.
				service.delete(fileLocation);

			}
		} catch (IOException e) {
			logger.error("Error during uploading file.", e);
			// throw new MyExceptionHandler("IOException", "uploadFile");
			e.printStackTrace();
		}
		if (result == true) {
			output = "File successfully uploaded!";
		} else {
			output = "Uploading Failed!";
		}
		ResponseMessage res = new ResponseMessage();
		res.setStatusCode(200);
		res.setMessage(output + " " + fileLocation);
		return res;
	}

	public Response downloadFile(HttpServletRequest request) {

		//get userid from session
		
		FileModel f1 = new FileModel();
		f1.setFileName(request.getParameter("FileName"));
		//f1.setUserID(userid);
		f1.setCategory_ID(Integer.parseInt(request.getParameter("CategoryID")));

		MyFileDAO d = new MyFileDAO();
		f1=d.viewFile(f1);//extracting all details of file.
		
		String path=d.downloadFile(f1);
		
		File file = new File(path);
		
		String temp=f1.getFileName()+"."+f1.getFileType();
		
		ResponseBuilder responseBuilder = Response.ok((Object) file);
		responseBuilder.header("Content-Disposition","attachment; filename=temp");
		return responseBuilder.build();

	}
	private void delete(String FileLocation) {
		File file = new File(FileLocation);
		file.delete();
	}

}