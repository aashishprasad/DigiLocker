package com.java.exception;

import javax.ws.rs.core.Response;

public class MyExceptionHandler extends Throwable {

	private String ErrorMessage = "";
	private String ExceptionName = "";
	private String MethodName = "";

	public MyExceptionHandler(String ExceptionName, String MethodName) {
		this.ExceptionName = ExceptionName;
		this.MethodName = MethodName;

		ExceptionHandler();
		errMessage();
	}

	private void ExceptionHandler() {
		if (ExceptionName.equals("IOException")) {
			if (MethodName.equals("uploadFile")) {
				ErrorMessage = "Unable to upload file. Please try again later.";
			}
		}
	}

	private Response errMessage() {

		return Response.status(200).entity("Error:" + ErrorMessage).build();

	}
}
