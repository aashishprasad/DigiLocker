package com.java.interfaces;

import com.java.model.FileModel;

public interface FileDAO {

	public boolean uploadFile(String fileLocation,FileModel f1);
	//public String downloadFile(String filename,String userid);
	public String downloadFile();//to be removed.
	public FileModel viewFile(FileModel file);
	public void deleteFile();
}
