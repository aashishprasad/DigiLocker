package com.java.interfaces;

import com.java.model.FileModel;

public interface FileDAO {

	public boolean uploadFile(String fileLocation,FileModel f1);
	public void downloadFile();
	public void viewFile();
	public void deleteFile();
}
