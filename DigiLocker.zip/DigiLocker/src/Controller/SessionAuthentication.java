package Controller;

public class SessionAuthentication {
	

	public boolean validateSession(int sess_id) {
		
		return true;
	}
	// this class will authenticate session id.
}
