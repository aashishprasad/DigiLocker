package com.java.rest.webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataParam;

import Controller.UserAuthentication;
import Controller.Validation;

import com.java.DAO.MyUserDAO;
import com.java.Helper.EmailVerification;
import com.java.model.User;

@Path("/user")
public class UserService {

	@POST
	@Path("/login")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response login(@FormDataParam("username") String username,
			@FormDataParam("password") String password) {

		if (username.equals("") || password.equals("")) {
			return Response.status(200).entity(
					"Username or Password cannot be blank.").build();
		} else {

			User user = new User();
			user.setUsername(username);
			user.setPassword(password);

			UserAuthentication auth = new UserAuthentication(user);
			boolean result = auth.UserValidate();

			if (result) {
				// create new session and store it in database.
				return Response.status(200).entity("Login Successful").build();
			} else {
				return Response.status(200).entity(
						"Incorrect Username or Password.").build();
			}
		}

	}

	@POST
	@Path("/register")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response register(@FormDataParam("username") String username,
			@FormDataParam("password") String password,
			@FormDataParam("name") String name,
			@FormDataParam("email") String email,
			@FormDataParam("mobile") String mobile,
			@FormDataParam("country") String country) {

		if (username.equals("") || password.equals("") || name.equals("")
				|| email.equals("") || mobile.equals("")) {
			return Response.status(200).entity("All fields are mandatory.")
					.build();
		} else {

			User user = new User();
			user.setUsername(username);
			user.setPassword(password);
			user.setName(name);
			user.setEmail(email);
			user.setMobile(mobile);
			user.setCountry(country);
			user.setStatus("active");

			MyUserDAO d = new MyUserDAO();

			Validation valid = new Validation();
			boolean usernameisvalid = valid.validateUsername(username);// validating
			// username

			if (usernameisvalid) {

				boolean emailisvalid = valid.validateEmail(email);
				if (emailisvalid) {
					boolean result = d.createNewUser(user);
					if (result) {
						// EmailVerification.emailVerify(user);//to verify and
						// activate account.
						return Response
								.status(200)
								.entity(
										"Registration Successful. Welcome to DigiLocker!")
								.build();
					} else {
						return Response
								.status(200)
								.entity(
										"Registration Failed due to internal error. Please try again later.")
								.build();
					}
				} else {
					return Response
							.status(200)
							.entity(
									"Email ID is already registered with an account. Please enter a valid email ID.")
							.build();
				}
			} else {
				return Response
						.status(200)
						.entity(
								"Username has already been taken. Please try another username.")
						.build();
			}

		}
	}

	@GET
	@Path("/verify")
	public Response verify(@PathParam("token") String id) {

		MyUserDAO dao = new MyUserDAO();
		String Username = dao.verifyToken(id);

		if (Username != null) {
			boolean result = dao.setStatus(Username);
			dao.deleteToken(id);//deleting token from database.
			if (result) {
				return Response
						.status(200)
						.entity(
								"Congratulations! You have successfully verified your email id. Your account is ready to be used.")
						.build();
			}
		}
		return Response.status(200).entity("Invalid Request. Link has been expired.").build();

	}

}
