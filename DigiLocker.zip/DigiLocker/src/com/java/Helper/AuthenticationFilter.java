package com.java.Helper;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.SecretKey;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class AuthenticationFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub

	}

	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest) req;
		Cookie[] cookies = request.getCookies();
        if (cookies != null){
          for (Cookie ck : cookies) {
            if ("nameOfMyCookie".equals(ck.getName())) {
                // read the cookie etc, etc
                // ....
                // set an object in the current request
                //request.setAttribute("myCoolObject", myObject);
            }
        }
	
        }
        
        File keyfile = new File("c://test//key.file");
        if(!keyfile.exists()){
        	 //generating secret key and saving in a file.
      		try {
      			SecretKey originalKey = KeyStoreUtils.generateKey();
      			
      			File file = new File("c://test//key.file");
      			KeyStoreUtils.saveKey(originalKey, file);
      		} catch (NoSuchAlgorithmException e) {
      			// TODO Auto-generated catch block
      			e.printStackTrace();
      		}
        }else
        {
      	  System.out.println("file exits!");
        }
        System.out.println("THIS IS AUTHENTICATION FILTER!");
		chain.doFilter(req, res);
    }

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
