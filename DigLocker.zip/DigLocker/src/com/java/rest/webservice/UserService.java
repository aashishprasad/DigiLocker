package com.java.rest.webservice;

import Controller.UserAuthentication;
import Controller.Validation;

import com.java.DAO.MyUserDAO;
import com.java.model.User;

public class UserService {

	public boolean login(String username, String password) {

		User user = new User();
		user.setUsername(username);
		user.setPassword(password);

		UserAuthentication auth = new UserAuthentication(user);
		boolean result = auth.UserValidate();

		return result;
	}

	public String register(String username, String password, String name,
			String email, String mobile, String country) {

		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setName(name);
		user.setEmail(email);
		user.setMobile(mobile);
		user.setCountry(country);
		user.setStatus("active");// to be removed.
		// user.setStatus("inactive");

		MyUserDAO d = new MyUserDAO();

		Validation valid = new Validation();
		boolean usernameisvalid = valid.validateUsername(username);// validating
		// username

		if (usernameisvalid) {

			boolean emailisvalid = valid.validateEmail(email);
			if (emailisvalid) {
				boolean result = d.createNewUser(user);
				if (result) {
					// EmailVerification.emailVerify(user);//to verify and
					// activate account.
					return "success";// Registration Successful
				} else {
					return "internal_error";
				}
			} else {
				return "email_error";
			}
		} else {
			return "username_error";
		}

	}

	public boolean verify(String id) {

		MyUserDAO dao = new MyUserDAO();
		String Username = dao.verifyToken(id);

		if (Username != null) {
			boolean result = dao.setStatus(Username);
			dao.deleteToken(id);// deleting token from database.
			if (result) {
				return true;
			}
		}
		return false;

	}

}
