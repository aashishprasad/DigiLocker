package com.java.Helper;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str="name(1)";
		
		System.out.println("value+"+str.contains("("));

	}

}
