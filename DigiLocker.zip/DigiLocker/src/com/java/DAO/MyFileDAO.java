package com.java.DAO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

import javax.smartcardio.CommandAPDU;

import com.java.Helper.GetFileExtension;
import com.java.dbconnection.DBUtil;
import com.java.interfaces.FileDAO;
import com.java.model.FileModel;

public class MyFileDAO implements FileDAO {

	// This class is used to interact with the database.
	private Connection con = null;
	private Statement stmt = null;

	public void downloadFile() {
		// connecting to database.
		DBUtil d = new DBUtil();
		con = d.getConnection();

		try {
			stmt = con.createStatement();

			String sql = "SELECT * FROM IMGTABLE WHERE NAME='desert'";
			ResultSet rs;

			rs = stmt.executeQuery(sql);

			// Extract data from result set

			while (rs.next()) {
				// Retrieve by column name
				String name = rs.getString("name");
				Blob last = rs.getBlob("photo");

			}

			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean uploadFile(String fileLocation, FileModel f1) {
		// connecting to database.
		DBUtil d = new DBUtil();
		con = d.getConnection();

		PreparedStatement ps;
		try {
			ps = con.prepareStatement("insert into FILE_DETAILS values(?,?,?)");
			String uniqueID = UUID.randomUUID().toString();
			String ext =GetFileExtension.getFileExtension(fileLocation); // returns "txt"
			ps.setString(1,"");
			ps.setString(2,"");

			FileInputStream fin;

			fin = new FileInputStream(fileLocation);

			ps.setBinaryStream(3, fin, fin.available());

			int i;

			i = ps.executeUpdate();
		
			System.out.println(i + " records affected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return true;

	}

	private String getFileExtension(String fileLocation) {
		// TODO Auto-generated method stub
		return null;
	}

	public void viewFile() {
		// TODO Auto-generated method stub

	}

	public void deleteFile() {
		// connecting to database.
		DBUtil d = new DBUtil();
		con = d.getConnection();

	}

}
