package com.java.rest.webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataParam;

import Controller.UserAuthentication;

import com.java.model.User;

@Path("/user")
public class UserService {
	
	@POST
	@Path("/login")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response login(	@FormDataParam("username") String username,
			@FormDataParam("password") String password){
		
		User user=new User();
		user.setUsername(username);
		user.setPassword(password);
		
		UserAuthentication auth=new UserAuthentication(user);
		boolean result=auth.UserValidate();
		
		if(result){
			
		}else{
			
		}
		
		return Response.status(200).entity("User Service").build();
		
	}

}
