package com.java.rest.webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataParam;

import Controller.UserAuthentication;

import com.java.DAO.MyUserDAO;
import com.java.model.User;

@Path("/user")
public class UserService {

	@POST
	@Path("/login")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response login(@FormDataParam("username") String username,
			@FormDataParam("password") String password) {

		User user = new User();
		user.setUsername(username);
		user.setPassword(password);

		UserAuthentication auth = new UserAuthentication(user);
		boolean result = auth.UserValidate();

		if (result) {
			//create new session and store it in database.
			return Response.status(200).entity("Login Successful").build();
		} else {
			return Response.status(200).entity("Login Failed").build();
		}


	}

	@POST
	@Path("/register")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response register(@FormDataParam("username") String username,
			@FormDataParam("password") String password,
			@FormDataParam("name") String name,
			@FormDataParam("email") String email,
			@FormDataParam("mobile") String mobile) {

		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setName(name);
		user.setEmail(email);
		user.setMobile(mobile);

		MyUserDAO d = new MyUserDAO();
		boolean result = d.createNewUser(user);
		if (result) {
			
			return Response.status(200).entity("Registration Successful")
					.build();
		} else {
			return Response.status(200).entity("User Already Exists!").build();
		}

	}

}
