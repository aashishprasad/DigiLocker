package com.java.Helper;

import java.util.Random;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.java.DAO.MyUserDAO;
import com.java.model.User;

public class EmailVerification {

	final static String path="http://localhost:8080/DigiLocker/rest/user/verify";
	public static void emailVerify(User user){
	
		int token=TokenGenerator.getToken();
		
		String msg="Please click on the below link to verify and activate your DigiLocker account."+path+"/"+token;
		
		try {
			EmailUtility.sendEmail("smtp.gmail.com", "587", "aashish.pd097@gmail.com", "password", user.getEmail(),"DigiLocker:Account Activation",msg);
			
			//storing token number in database..
			MyUserDAO db=new MyUserDAO();
			db.tokenStore(user.getUsername(),token);
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
