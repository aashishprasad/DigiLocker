package com.java.Helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import com.java.exception.MyExceptionHandler;

public class AuthenticationFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub

	}

	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		boolean isValid = isValidRequest(req);
		if (isValid) {
			chain.doFilter(req, res);
		} else {
			new MyExceptionHandler(null, "request validation failed");
		}
	}

	private boolean isValidRequest(ServletRequest request) {

		Cookie[] cookies = ((HttpServletRequest) request).getCookies();
		if (cookies != null) {

			ArrayList<Cookie> arr = (ArrayList<Cookie>) Arrays.asList(cookies);
			boolean result = arr.contains("mycookiename");
			if (result) {
				//get the session_id from the cookie and validate it from the session table in databse.
				
				return true;
			} else {
				// return false;
				return true;// assuming valid cookie.
			}
		}
		//return false;
		return true;
	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
