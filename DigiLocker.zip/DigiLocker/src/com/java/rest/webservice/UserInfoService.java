package com.java.rest.webservice;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataParam;

import Controller.Validation;

import com.java.DAO.MyUserDAO;
import com.java.Helper.EmailUtility;
import com.java.Helper.TokenGenerator;
import com.java.model.User;

@Path("/userinfo")
public class UserInfoService {

	@POST
	@Path("/reset")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response resetPassword(@FormDataParam("username") String username) {

		if (username.equals("")) {
			return Response.status(200).entity(
					"Username cannot be blank. Please enter a valid username.")
					.build();
		} else {

			MyUserDAO dao = new MyUserDAO();
			User user = dao.getUserbyUsername(username);
			if (user != null) {

				int newPassword = TokenGenerator.getToken();
				String msg = "Your new DigiLocker password is" + " "
						+ newPassword;

				try {
					EmailUtility
							.sendEmail("smtp.gmail.com", "587",
									"aashish.pd097@gmail.com", "password", user
											.getEmail(),
									"DigiLocker:New Passowrd", msg);

					// changing password in database.
					dao.changePassword(username, newPassword);

				} catch (AddressException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				return Response
						.status(200)
						.entity(
								"Email has been sent to your registered email account. Please login to access your new password.")
						.build();
			} else {
				return Response
						.status(200)
						.entity(
								"Invalid Username. User does not exists. Please enter a valid username.")
						.build();
			}

		}
	}

	@POST
	@Path("/update")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response register(@PathParam("username") String username,
			@FormDataParam("name") String name,
			@FormDataParam("email") String email,
			@FormDataParam("mobile") String mobile,
			@FormDataParam("country") String country) {

		if (name.equals("") || email.equals("") || mobile.equals("")|| country.equals("")) {
			return Response.status(200).entity("Field cannot be left blank.")
					.build();
		} else {

			User user = new User();
			user.setUsername(username);
			user.setName(name);
			user.setEmail(email);
			user.setMobile(mobile);
			user.setCountry(country);

			MyUserDAO d = new MyUserDAO();

			Validation valid = new Validation();

			boolean emailisvalid = valid.validateEmail(email);
			if (emailisvalid) {

				// EmailVerification.emailVerify(user);
				boolean result = d.UpdateUserInfo(user);
				if (result) {
					return Response.status(200).entity(
							"Information Successfully Updated.").build();
				} else {
					return Response
							.status(200)
							.entity(
									"Updation Failed due to internal error. Please try again later.")
							.build();
				}
			} else {
				return Response
						.status(200)
						.entity(
								"Email ID is already registered with an account. Please enter a valid email ID.")
						.build();
			}

		}
	}
}
