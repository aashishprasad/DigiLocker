package com.java.exception;

public class MyExceptionHandler {

	public MyExceptionHandler(Exception e, String msg) {

		if (msg.equals("IOException")) {
			System.out.println("Error: Unable to fetch file on server.");
		}

	}
}
