package com.java.rest.webservice;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.java.DAO.MyFileDAO;
import com.java.Helper.Encryption;
import com.java.Helper.GetFileExtension;
import com.java.exception.MyExceptionHandler;
import com.java.model.FileModel;
import com.java.resource.property.PropertyLoader;


@Path("/files")
public class FileService {

	private boolean result;
	private String output;
	final static Logger logger = Logger.getLogger(FileService.class);

	@POST
	@Path("/upload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFile(

	@FormDataParam("file") InputStream uploadedInputStream,
			@FormDataParam("file") FormDataContentDisposition fileDetail,
			@FormDataParam("file_name") String name,
			@FormDataParam("secure") String secure,
			@FormDataParam("file_description") String description)throws MyExceptionHandler {

		String fileLocation = PropertyLoader
				.getPropertyValue("dcryptedfilepath")
				+ fileDetail.getFileName();
		// saving file on server.
		try {
			FileOutputStream out = new FileOutputStream(new File(fileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
			System.gc();
			
			
			
			//getting parameter values into FileModel  object.
			FileModel f1 = new FileModel();
			f1.setFileName(name);
			// f1.setUserID(userID);
			f1.setDescription(description);
			//f1.setCategory_ID(category_id);
			f1.setFileType(GetFileExtension.getFileExtension(fileLocation));// getting
																			// file_extension.

			FileService service = new FileService();// object of FileService
													// class.
			if (secure != null) {
				f1.setSecure("yes");
				String oldFileLocation = fileLocation;
				// encrypting file.
				Encryption enc = new Encryption();
				fileLocation = enc.encryptFile(fileLocation, fileDetail
						.getFileName());

				// deleting old file from server.
				service.delete(oldFileLocation);

			} else
				f1.setSecure("no");

			// file uploading in database.
			MyFileDAO d = new MyFileDAO();
			result = d.uploadFile(fileLocation, f1);

			// deleting file from server.
			service.delete(fileLocation);

		} catch (IOException e) {
			logger.error("Error during uploading file.", e);
			throw new MyExceptionHandler("IOException", "uploadFile");
		}
		if (result == true) {
			output = "File successfully uploaded!";
		} else {
			output = "Uploading Failed!";
		}

		return Response.status(200).entity(output + " " + fileLocation).build();

	}

	private void delete(String FileLocation) {
		File file = new File(FileLocation);
		file.delete();
	}

	@GET
	@Path("/download")
	public Response downloadFile() {

		FileModel f1 = new FileModel();
		// f1.setFileName(fileName);
		// f1.setUserID(userid);

		MyFileDAO d = new MyFileDAO();
		//f1=d.viewFile(f1);//extracting all details of file.
		
		// String path=d.downloadFile(f1);
		String path = d.downloadFile();// to be removed.
		
		File file = new File(path);
		
		ResponseBuilder responseBuilder = Response.ok((Object) file);
		//responseBuilder.header("Content-Disposition","attachment; filename=f1.getFileName()+"."+f1.getFileType()");
		responseBuilder.header("Content-Disposition","attachment; filename=\"MyImageFile.jpg\"");//to be removed.
		return responseBuilder.build();

	}

	@POST
	@Path("/delete")
	public Response deleteFile() {
		return null;

	}
}