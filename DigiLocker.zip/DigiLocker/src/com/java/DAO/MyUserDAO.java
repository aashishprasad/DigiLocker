package com.java.DAO;

import com.java.interfaces.UserDAO;
import com.java.model.User;

public class MyUserDAO implements UserDAO{

	public boolean createNewUser(User u) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteUser(User u) {
		// TODO Auto-generated method stub
		return false;
	}

	public User getUser(String username2) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
