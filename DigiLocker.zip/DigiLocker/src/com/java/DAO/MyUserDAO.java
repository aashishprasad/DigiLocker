package com.java.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.java.dbconnection.DBUtil;
import com.java.interfaces.UserDAO;
import com.java.model.User;

public class MyUserDAO implements UserDAO {

	public boolean createNewUser(User u) {
		User user = getUser(u.getUsername());
		if (user == null) {
			
			//getting connection.
			DBUtil db = new DBUtil();
			Connection con = db.getConnection();
			
			//get all user details from user model and set them in database.
			
			PreparedStatement ps;
			try {
				ps= con.prepareStatement("insert into USER_DETAILS values(?,?,?)");
				ps.setString(1, u.getUsername());
				ps.setString(2, u.getPassword());
				ps.setString(3, u.getEmail());
				ps.setString(4, u.getMobile());
				ps.setString(5, u.getName());
				
				ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return true;
		} else
			return false;
	}

	public boolean deleteUser(User u) {
		User user = getUser(u.getUsername());
		if (user!=null) {
			
			//getting connection.
			DBUtil db = new DBUtil();
			Connection con = db.getConnection();
			
			//deleting user from database.
			
			return true;
		} else
			return false;
	}

	public User getUser(String username) {
		
		//getting connection.
		DBUtil db = new DBUtil();
		Connection con = db.getConnection();
		
		// this method will get user details from database.
		return null;
	}

}
